
import { DEFAULT_RESOURCE_TYPES, prettyfy } from "./utils.js";

const RULES_KEY = "oro_rules";
const MASTER_ENABLED_KEY = "oro_master_enabled";

const els = {
  masterEnabled: document.getElementById("masterEnabled"),
  exportBtn: document.getElementById("exportBtn"),
  importBtn: document.getElementById("importBtn"),
  importFile: document.getElementById("importFile"),

  editorTitle: document.getElementById("editorTitle"),
  form: document.getElementById("ruleForm"),
  ruleId: document.getElementById("ruleId"),
  name: document.getElementById("name"),
  enabled: document.getElementById("enabled"),
  matchType: document.getElementById("matchType"),
  pattern: document.getElementById("pattern"),
  exclude: document.getElementById("exclude"),
  caseSensitive: document.getElementById("caseSensitive"),
  action: document.getElementById("action"),
  priority: document.getElementById("priority"),

  redirectUrlRow: document.getElementById("redirectUrlRow"),
  redirectUrl: document.getElementById("redirectUrl"),

  mockRow: document.getElementById("mockRow"),
  mockKind: document.getElementById("mockKind"),
  mockStatus: document.getElementById("mockStatus"),
  mockMode: document.getElementById("mockMode"),
  waitForReal: document.getElementById("waitForReal"),
  mockBody: document.getElementById("mockBody"),
  prettyBtn: document.getElementById("prettyBtn"),

  headersRow: document.getElementById("headersRow"),
  headersList: document.getElementById("headersList"),
  addHeaderBtn: document.getElementById("addHeaderBtn"),
  exposeHeaders: document.getElementById("exposeHeaders"),

  injectRow: document.getElementById("injectRow"),
  injectBody: document.getElementById("injectBody"),
  prettyInjectBtn: document.getElementById("prettyInjectBtn"),

  resourceTypes: document.getElementById("resourceTypes"),
  rules: document.getElementById("rules"),
  saveBtn: document.getElementById("saveBtn"),
  resetBtn: document.getElementById("resetBtn"),
};

let state = { rules: [], masterEnabled: true };

function cid() { return String(Date.now()) + "-" + Math.random().toString(36).slice(2,8); }

async function load() {
  const data = await chrome.storage.local.get([RULES_KEY, MASTER_ENABLED_KEY]);
  state.rules = Array.isArray(data[RULES_KEY]) ? data[RULES_KEY] : [];
  state.masterEnabled = (typeof data[MASTER_ENABLED_KEY] === "boolean") ? data[MASTER_ENABLED_KEY] : true;
  els.masterEnabled.checked = !!state.masterEnabled;
  renderRules();
}
load();

els.masterEnabled.addEventListener("change", async (e) => {
  const enabled = !!e.currentTarget.checked;
  await chrome.runtime.sendMessage({ type: "oro-toggle-master", enabled });
});

function renderResourceTypeChips(currentSelection) {
  const selected = new Set(Array.isArray(currentSelection) && currentSelection.length ? currentSelection : DEFAULT_RESOURCE_TYPES);
  els.resourceTypes.innerHTML = "";
  for (const t of DEFAULT_RESOURCE_TYPES) {
    const d = document.createElement("div");
    d.className = "chip" + (selected.has(t) ? " selected" : "");
    d.textContent = t;
    d.dataset.type = t;
    d.addEventListener("click", () => {
      d.classList.toggle("selected");
    });
    els.resourceTypes.appendChild(d);
  }
}

function resetForm() {
  els.editorTitle.textContent = "Add Rule";
  els.ruleId.value = "";
  els.name.value = "";
  els.enabled.checked = true;
  els.matchType.value = "wildcard";
  els.pattern.value = "";
  els.exclude.value = "";
  els.caseSensitive.checked = false;
  els.action.value = "redirectUrl";
  els.priority.value = "1";
  els.redirectUrl.value = "";
  els.mockKind.value = "json";
  els.mockStatus.value = "200";
  els.mockMode.value = "immediate";
  els.waitForReal.checked = false;
  els.mockBody.value = "";
  els.headersList.innerHTML = "";
  els.injectBody.value = "";
  renderResourceTypeChips();
  updateActionVisibility();
}

function updateActionVisibility() {
  const act = els.action.value;
  els.redirectUrlRow.classList.toggle("active", act === "redirectUrl");
  els.mockRow.classList.toggle("active", act === "mockText");
  els.headersRow.classList.toggle("active", act === "modifyHeaders");
  els.injectRow.classList.toggle("active", act === "injectJS" || act === "injectCSS");
}

function addHeaderRow(h = { header: "", operation: "set", value: "" }) {
  const headerVal = (h && h.header) ? h.header : "";
  const op = (h && h.operation) ? h.operation : "set";
  const valueVal = (h && typeof h.value === "string") ? h.value : "";

  const row = document.createElement("div");
  row.className = "header-row";
  row.innerHTML = `
    <input placeholder="Header name" value="${headerVal.replace(/"/g,'&quot;')}">
    <select>
      <option value="set" ${op !== "remove" ? "selected": ""}>set</option>
      <option value="remove" ${op === "remove" ? "selected": ""}>remove</option>
    </select>
    <input placeholder="Value" value="${valueVal.replace(/"/g,'&quot;')}">
    <button type="button" title="Delete">✕</button>
  `;
  const delEl = row.querySelector("button");
  delEl.addEventListener("click", () => row.remove());
  els.headersList.appendChild(row);
}

function collectHeaders() {
  const rows = els.headersList.querySelectorAll(".header-row");
  const out = [];
  rows.forEach(r => {
    const inputs = r.querySelectorAll("input, select");
    const header = inputs[0].value.trim();
    const operation = inputs[1].value;
    const value = inputs[2].value;
    if (header) out.push({ header, operation, value });
  });
  return out;
}

function renderRules() {
  els.rules.innerHTML = "";
  state.rules.forEach((r, idx) => {
    const item = document.createElement("div");
    item.className = "item";
    const meta = `${r.matchType}:${r.pattern} • ${r.action}` + (r.action==="mockText" ? ` [${(r.mock?.mode)||"immediate"}]` : "");
    item.innerHTML = `
      <input type="checkbox" ${r.enabled ? "checked": ""}>
      <div>
        <div class="name">${r.name || "(no name)"}</div>
        <div class="meta">${meta}</div>
      </div>
      <button data-act="edit">Edit</button>
      <button data-act="dup">Duplicate</button>
      <button data-act="del">Delete</button>
    `;
    const chk = item.querySelector('input[type="checkbox"]');
    chk.addEventListener("change", async () => {
      r.enabled = chk.checked;
      await chrome.storage.local.set({ [RULES_KEY]: state.rules });
    });
    item.querySelector('[data-act="edit"]').addEventListener("click", () => {
      els.editorTitle.textContent = "Edit Rule";
      els.ruleId.value = r.id;
      els.name.value = r.name || "";
      els.enabled.checked = !!r.enabled;
      els.matchType.value = r.matchType || "wildcard";
      els.pattern.value = r.pattern || "";
      els.exclude.value = (r.exclude || []).join(", ");
      els.caseSensitive.checked = !!r.isCaseSensitive;
      els.action.value = r.action || "redirectUrl";
      els.priority.value = r.priority || 1;
      els.redirectUrl.value = r.redirectUrl || "";
      els.mockKind.value = (r.mock && r.mock.kind) || "json";
      els.mockStatus.value = (r.mock && (r.mock.status || 200)) || 200;
      els.mockMode.value = (r.mock && r.mock.mode) || "immediate";
      els.waitForReal.checked = !!(r.mock && r.mock.waitForRealResponse);
      els.mockBody.value = (r.mock && r.mock.body) || "";
      els.headersList.innerHTML = "";
      (r.headers || []).forEach(h => addHeaderRow(h));
      els.injectBody.value = (r.inject && r.inject.body) || "";
      renderResourceTypeChips(Array.isArray(r.resourceTypes) ? r.resourceTypes : DEFAULT_RESOURCE_TYPES);
      updateActionVisibility();
    });
    item.querySelector('[data-act="dup"]').addEventListener("click", async () => {
      const copy = JSON.parse(JSON.stringify(r));
      copy.id = cid();
      copy.name = (copy.name || "") + " (copy)";
      state.rules.push(copy);
      await chrome.storage.local.set({ [RULES_KEY]: state.rules });
    });
    item.querySelector('[data-act="del"]').addEventListener("click", async () => {
      state.rules.splice(idx, 1);
      await chrome.storage.local.set({ [RULES_KEY]: state.rules });
    });
    els.rules.appendChild(item);
  });
}

els.action.addEventListener("change", updateActionVisibility);
els.prettyBtn.addEventListener("click", () => {
  const kind = els.mockKind.value;
  els.mockBody.value = prettyfy(kind === "auto" ? "json" : kind, els.mockBody.value);
});
els.prettyInjectBtn.addEventListener("click", () => {
  const kind = (els.action.value === "injectCSS") ? "css" : "js";
  els.injectBody.value = prettyfy(kind, els.injectBody.value);
});
els.addHeaderBtn.addEventListener("click", () => addHeaderRow());
els.resetBtn.addEventListener("click", resetForm);

els.form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = els.ruleId.value || cid();
  const resourceTypes = Array.from(els.resourceTypes.querySelectorAll(".chip.selected")).map(c => c.dataset.type);
  const desc = {
    id,
    name: els.name.value.trim(),
    enabled: els.enabled.checked,
    matchType: els.matchType.value,
    pattern: els.pattern.value.trim(),
    exclude: els.exclude.value.trim() ? els.exclude.value.split(",").map(s=>s.trim()).filter(Boolean) : [],
    isCaseSensitive: els.caseSensitive.checked,
    action: els.action.value,
    priority: Number(els.priority.value) || 1,
    resourceTypes
  };
  if (desc.action === "redirectUrl") {
    desc.redirectUrl = els.redirectUrl.value.trim();
  } else if (desc.action === "mockText") {
    desc.mock = {
      kind: els.mockKind.value,
      status: Number(els.mockStatus.value) || 200,
      mode: els.mockMode.value,
      waitForRealResponse: !!els.waitForReal.checked,
      body: els.mockBody.value
    };
  } else if (desc.action === "modifyHeaders") {
    desc.headers = collectHeaders();
  } else if (desc.action === "injectJS" || desc.action === "injectCSS") {
    desc.inject = { body: els.injectBody.value };
  }
  const idx = state.rules.findIndex(r => r.id === id);
  if (idx >= 0) { state.rules[idx] = desc; } else { state.rules.push(desc); }
  await chrome.storage.local.set({ [RULES_KEY]: state.rules });
  resetForm();
});

els.exportBtn.addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(state.rules, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = "oro-rules.json"; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
els.importBtn.addEventListener("click", () => els.importFile.click());
els.importFile.addEventListener("change", async (e) => {
  const f = e.target.files[0]; if (!f) return;
  const text = await f.text();
  try { const list = JSON.parse(text); if (Array.isArray(list)) { state.rules = list; await chrome.storage.local.set({ [RULES_KEY]: state.rules }); } }
  catch { alert("Invalid JSON"); } finally { e.target.value = ""; }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[RULES_KEY]) { state.rules = changes[RULES_KEY].newValue || []; renderRules(); }
});

resetForm();


// ---- Theme toggle (persisted) ----
(async function themeInit(){
  const { oro_theme } = await chrome.storage.local.get(["oro_theme"]);
  const current = oro_theme || "light";
  document.body.setAttribute("data-theme", current);
  const btn = document.getElementById("themeToggle");
  if (btn) {
    btn.addEventListener("click", async () => {
      const now = document.body.getAttribute("data-theme") === "dark" ? "light" : "dark";
      document.body.setAttribute("data-theme", now);
      await chrome.storage.local.set({ oro_theme: now });
      btn.textContent = (now === "dark") ? "☀️" : "🌙";
    });
    btn.textContent = (current === "dark") ? "☀️" : "🌙";
  }
})();
