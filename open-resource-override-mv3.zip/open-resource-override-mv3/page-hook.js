// Runs in the page's MAIN world. Injected via scripting API (CSP-safe).
// Overrides fetch/XHR for AFTER-response rules; DNR handles IMMEDIATE.

(function() {
  if (window.__oroMainInstalled) return;
  window.__oroMainInstalled = true;

  const ORO = { enabled: true, rules: [] };
  const toAbs = (u) => { try { return new URL(u, location.href).href; } catch { return String(u||""); } };
  const matchUrl = (u, r, cs) => { try { return new RegExp(r, cs ? "" : "i").test(u); } catch { return false; } };

  window.addEventListener("message", (ev) => {
    if (!ev || !ev.data) return;
    const d = ev.data;
    if (d.type === "oro-update-rules" && d.payload) {
      ORO.enabled = !!d.payload.enabled;
      ORO.rules = Array.isArray(d.payload.rules) ? d.payload.rules : [];
    }
  });

  // ---- Fetch ----
  const _fetch = window.fetch.bind(window);
  window.fetch = async function(input, init) {
    const req = (typeof input === 'string' || (input && !('clone' in input))) ? new Request(input, init) : input;
    const abs = toAbs(req.url || input);
    if (!ORO.enabled) return _fetch(req);
    const matches = ORO.rules.filter(r =>
      r.enabled && r.action === "mockText" && r.mock && r.mock.mode === "after" &&
      r._compiledRegex && matchUrl(abs, r._compiledRegex, !!r.isCaseSensitive)
    );
    if (!matches.length) return _fetch(req);
    const rule = matches[matches.length - 1];
    const body = (rule.mock && rule.mock.body) || "";
    const status = (rule.mock && Number(rule.mock.status)) || 200;
    const kind = (rule.mock && rule.mock.kind) || "auto";
    const guessCT = (k,t)=>{ if(k!=="auto"){ if(k==="json")return"application/json; charset=utf-8"; if(k==="js")return"text/javascript; charset=utf-8"; if(k==="css")return"text/css; charset=utf-8"; } t=(t||"").trim(); if(t.startsWith("{")||t.startsWith("["))return"application/json; charset=utf-8"; if(t.startsWith("/*")||t.includes("function")||t.includes("=>"))return"text/javascript; charset=utf-8"; if(t.includes("{")&&t.includes("}"))return"text/css; charset=utf-8"; return"text/plain; charset=utf-8"; };
    const headers = new Headers({ "content-type": guessCT(kind, body) });
    if (Array.isArray(rule.headers)) for (const h of rule.headers) {
      const op=(h.operation||"set").toLowerCase();
      if(op==="set"&&h.header) headers.set(h.header,h.value||"");
      if(op==="remove"&&h.header) headers.delete(h.header);
    }
    if (rule.mock.waitForRealResponse) { try { await _fetch(req); } catch {} }
    return new Response(body, { status, headers });
  };

  // ---- XHR ----
  (function(){
    const _open = XMLHttpRequest.prototype.open;
    const _send = XMLHttpRequest.prototype.send;
    const _protoAdd = XMLHttpRequest.prototype.addEventListener;

    XMLHttpRequest.prototype.open = function(method, url, async=true, user, password) {
      this.__oroUrl = String(url);
      this.__oroRule = null;
      this.__oroWait = false;
      this.__oroBuffered = { load: [], readystatechange: [], loadend: [], error: [], abort: [] };

      if (ORO.enabled) {
        const abs = toAbs(this.__oroUrl || "");
        const matches = ORO.rules.filter(r =>
          r.enabled && r.action === "mockText" && r.mock && r.mock.mode === "after" &&
          r._compiledRegex && matchUrl(abs, r._compiledRegex, !!r.isCaseSensitive)
        );
        if (matches.length) {
          this.__oroOrigAdd = _protoAdd;
          const rule = matches[matches.length - 1];
          this.__oroRule = rule;
          this.__oroWait = !!(rule.mock && rule.mock.waitForRealResponse);

          // If waiting: buffer handler attachments now
          if (this.__oroWait) {
            const origAdd = this.addEventListener;
            this.addEventListener = function(type, listener, opts) {
              if (["load","readystatechange","loadend"].includes(type)) {
                this.__oroBuffered[type].push(listener);
                return origAdd.call(this, type, function(){/* swallow */}, opts);
              }
              return origAdd.call(this, type, listener, opts);
            };
            // Wrap property handlers
            Object.defineProperty(this, "onreadystatechange", {
              set: (fn) => { this.__oroBuffered.onreadystatechange_prop = fn; },
              get: () => this.__oroBuffered.onreadystatechange_prop
            });
            Object.defineProperty(this, "onload", {
              set: (fn) => { this.__oroBuffered.onload_prop = fn; },
              get: () => this.__oroBuffered.onload_prop
            });
            Object.defineProperty(this, "onloadend", {
              set: (fn) => { this.__oroBuffered.onloadend_prop = fn; },
              get: () => this.__oroBuffered.onloadend_prop
            });
          }
        }
      }
      return _open.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function(body) {
      const rule = this.__oroRule;
      if (!ORO.enabled || !rule || rule.action !== "mockText" || rule.mock.mode !== "after") {
        return _send.apply(this, arguments);
      }

      const mockBody = (rule.mock && rule.mock.body) || "";
      const status = (rule.mock && Number(rule.mock.status)) || 200;

      if (this.__oroWait) {
        // Let the REAL XHR go through, but swallow its completion callbacks, then replay with mock.
        const xhr = this;
        const onRealDone = () => {
          try { Object.defineProperty(xhr, "readyState", { value: 4 }); } catch {}
          try { Object.defineProperty(xhr, "status", { value: status }); } catch {}
          try { Object.defineProperty(xhr, "responseText", { value: mockBody }); } catch {}
          try { Object.defineProperty(xhr, "statusText", { value: (String(status) === '200' ? 'OK' : '') }); } catch {}
          try { Object.defineProperty(xhr, "response", { value: mockBody }); } catch {}
          const evRS = new Event("readystatechange");
          const evLoad = new Event("load");
          const evLE  = new Event("loadend");
          if (xhr.__oroBuffered.onreadystatechange_prop) try { xhr.__oroBuffered.onreadystatechange_prop.call(xhr, evRS); } catch {}
          if (xhr.__oroBuffered.onload_prop) try { xhr.__oroBuffered.onload_prop.call(xhr, evLoad); } catch {}
          if (xhr.__oroBuffered.onloadend_prop) try { xhr.__oroBuffered.onloadend_prop.call(xhr, evLE); } catch {}
          for (const fn of xhr.__oroBuffered.readystatechange) try { fn.call(xhr, evRS); } catch {}
          for (const fn of xhr.__oroBuffered.load) try { fn.call(xhr, evLoad); } catch {}
          for (const fn of xhr.__oroBuffered.loadend) try { fn.call(xhr, evLE); } catch {}
        };
        if (this.__oroOrigAdd) { this.__oroOrigAdd.call(this, "loadend", onRealDone, { once: true }); } else { this.addEventListener("loadend", onRealDone, { once: true }); }
        return _send.apply(this, arguments);
      } else {
        const xhr = this;
        setTimeout(() => {
          try { Object.defineProperty(xhr, "readyState", { value: 4 }); } catch {}
          try { Object.defineProperty(xhr, "status", { value: status }); } catch {}
          try { Object.defineProperty(xhr, "responseText", { value: mockBody }); } catch {}
          try { Object.defineProperty(xhr, "statusText", { value: (String(status) === '200' ? 'OK' : '') }); } catch {}
          try { Object.defineProperty(xhr, "response", { value: mockBody }); } catch {}
          xhr.dispatchEvent(new Event("readystatechange"));
          xhr.dispatchEvent(new Event("load"));
          xhr.dispatchEvent(new Event("loadend"));
        }, 0);
        return;
      }
    };
  })();

  window.postMessage({ type: "oro-main-ready" }, "*");
})();
